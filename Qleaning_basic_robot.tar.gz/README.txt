Robô que percorre uma matriz 6x6 e tenta chegar a posição (4,5) utilizando o 
algoritimo Q_learning.
