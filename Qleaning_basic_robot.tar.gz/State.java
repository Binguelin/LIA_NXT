public class State {
	public int x;
	public int y;

	public State(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public void setState(int x, int y) {
		this.x = x;
		this.y = y;
	}
}